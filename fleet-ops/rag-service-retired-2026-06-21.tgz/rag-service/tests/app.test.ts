import { describe, expect, it } from 'vitest';
import { TtlCache } from '../src/cache';
import { createApp } from '../src/index';
import type {
  CreateChunkInput,
  CreateDocumentInput,
  CreateIndexInput,
  LexicalChunkRecord,
  Repository,
} from '../src/repository';
import type {
  ChunkRecord,
  DocumentRecord,
  Env,
  IndexRecord,
  JsonRecord,
  VectorizeBinding,
  VectorizeVector,
} from '../src/types';

class MemoryRepository implements Repository {
  indexes = new Map<string, IndexRecord>();
  documents = new Map<string, DocumentRecord>();
  chunks = new Map<string, ChunkRecord>();
  getIndexCalls = 0;

  async createIndex(input: CreateIndexInput): Promise<IndexRecord> {
    const row: IndexRecord = {
      id: input.id,
      tenant: input.tenant,
      name: input.name,
      external_id: input.externalId,
      dimensions: 768,
      metric: 'cosine',
      created_at: new Date(0).toISOString(),
    };
    this.indexes.set(row.id, row);
    return row;
  }

  async listIndexes(tenant: string): Promise<IndexRecord[]> {
    return [...this.indexes.values()].filter((row) => row.tenant === tenant);
  }

  async getIndex(tenant: string, id: string): Promise<IndexRecord | null> {
    this.getIndexCalls += 1;
    const row = this.indexes.get(id);
    return row?.tenant === tenant ? row : null;
  }

  async deleteIndex(tenant: string, id: string): Promise<void> {
    const row = this.indexes.get(id);
    if (row?.tenant === tenant) this.indexes.delete(id);
  }

  async createDocument(input: CreateDocumentInput): Promise<DocumentRecord> {
    const row: DocumentRecord = {
      id: input.id,
      index_id: input.indexId,
      tenant: input.tenant,
      external_id: input.externalId,
      content: input.content,
      metadata: input.metadata,
      created_at: new Date(0).toISOString(),
    };
    this.documents.set(row.id, row);
    return row;
  }

  async listDocuments(tenant: string, indexId: string): Promise<DocumentRecord[]> {
    return [...this.documents.values()].filter(
      (row) => row.tenant === tenant && row.index_id === indexId,
    );
  }

  async getDocument(tenant: string, id: string): Promise<DocumentRecord | null> {
    const row = this.documents.get(id);
    return row?.tenant === tenant ? row : null;
  }

  async deleteDocument(tenant: string, id: string): Promise<void> {
    const row = this.documents.get(id);
    if (row?.tenant === tenant) this.documents.delete(id);
  }

  async insertChunks(chunks: CreateChunkInput[]): Promise<void> {
    for (const chunk of chunks) {
      this.chunks.set(chunk.id, {
        id: chunk.id,
        document_id: chunk.documentId,
        index_id: chunk.indexId,
        tenant: chunk.tenant,
        content: chunk.content,
        chunk_index: chunk.chunkIndex,
        metadata: chunk.metadata,
        created_at: new Date(0).toISOString(),
      });
    }
  }

  async getChunksByIds(tenant: string, ids: string[]): Promise<ChunkRecord[]> {
    const rows: ChunkRecord[] = [];
    for (const id of ids) {
      const row = this.chunks.get(id);
      if (row && row.tenant === tenant) rows.push(row);
    }
    return rows;
  }

  async listChunksForIndex(tenant: string, indexId: string, limit: number): Promise<ChunkRecord[]> {
    return [...this.chunks.values()]
      .filter((row) => row.tenant === tenant && row.index_id === indexId)
      .sort((a, b) => a.chunk_index - b.chunk_index)
      .slice(0, limit);
  }

  async searchLexicalChunks(
    tenant: string,
    indexId: string,
    tokens: string[],
    limit: number,
  ): Promise<LexicalChunkRecord[]> {
    return [...this.chunks.values()]
      .filter((row) => row.tenant === tenant && row.index_id === indexId)
      .map((row) => ({
        ...row,
        lexical_score: tokens.filter((token) => row.content.toLowerCase().includes(token)).length,
      }))
      .filter((row) => row.lexical_score > 0)
      .sort((a, b) => b.lexical_score - a.lexical_score || a.chunk_index - b.chunk_index)
      .slice(0, limit);
  }

  async getChunkIdsForDocument(tenant: string, documentId: string): Promise<string[]> {
    return [...this.chunks.values()]
      .filter((row) => row.tenant === tenant && row.document_id === documentId)
      .map((row) => row.id);
  }

  async getChunkIdsForIndex(tenant: string, indexId: string): Promise<string[]> {
    return [...this.chunks.values()]
      .filter((row) => row.tenant === tenant && row.index_id === indexId)
      .map((row) => row.id);
  }
}

class FakeVectorize implements VectorizeBinding {
  vectors = new Map<string, VectorizeVector>();
  deleted: string[] = [];
  queries: Array<{ vector: number[]; filter?: JsonRecord; namespace?: string; returnMetadata?: unknown }> = [];

  async upsert(vectors: VectorizeVector[]): Promise<void> {
    for (const vector of vectors) this.vectors.set(vector.id, vector);
  }

  async query(
    vector: number[],
    options: { topK: number; filter?: JsonRecord; namespace?: string; returnMetadata?: unknown },
  ): Promise<{ matches: { id: string; score: number; metadata?: JsonRecord }[] }> {
    this.queries.push({
      vector,
      ...(options.filter ? { filter: options.filter } : {}),
      ...(options.namespace ? { namespace: options.namespace } : {}),
      ...(options.returnMetadata !== undefined ? { returnMetadata: options.returnMetadata } : {}),
    });
    const entries = [...this.vectors.values()].filter((candidate) => {
      if (options.namespace && candidate.namespace !== options.namespace) return false;
      return Object.entries(options.filter ?? {}).every(([key, value]) => {
        return candidate.metadata[key] === value;
      });
    });
    const matches = entries
      .map((candidate) => ({
        id: candidate.id,
        score: candidate.values.reduce((sum, value, i) => sum + value * (vector[i] ?? 0), 0),
        metadata: candidate.metadata,
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, options.topK);
    return { matches };
  }

  async deleteByIds(ids: string[]): Promise<void> {
    this.deleted.push(...ids);
    for (const id of ids) this.vectors.delete(id);
  }
}

class FakeQueryCacheD1 {
  rows = new Map<string, { tenant: string; indexId: string; payload: string; expiresAt: number }>();
  selectPayloadCalls = 0;
  insertCalls = 0;
  deleteCalls = 0;

  prepare(sql: string) {
    return {
      bind: (...args: unknown[]) => ({
        first: async () => {
          if (sql.includes('SELECT payload') && sql.includes('query_cache')) {
            this.selectPayloadCalls += 1;
            const [cacheKey, tenant, indexId, now] = args as [string, string, string, number];
            const row = this.rows.get(cacheKey);
            if (!row || row.tenant !== tenant || row.indexId !== indexId || row.expiresAt <= now) return null;
            return { payload: row.payload };
          }
          return { ok: 1 };
        },
        run: async () => {
          if (sql.includes('INSERT OR REPLACE INTO query_cache')) {
            this.insertCalls += 1;
            const [cacheKey, tenant, indexId, payload, expiresAt] = args as [string, string, string, string, number];
            this.rows.set(cacheKey, { tenant, indexId, payload, expiresAt });
          }
          if (sql.includes('DELETE FROM query_cache')) {
            this.deleteCalls += 1;
            const [tenant, indexId] = args as [string, string];
            for (const [key, row] of this.rows.entries()) {
              if (row.tenant === tenant && row.indexId === indexId) this.rows.delete(key);
            }
          }
          return { success: true };
        },
      }),
      first: async () => ({ ok: 1 }),
    };
  }
}

function vectorFor(text: string): number[] {
  return [text.length, text.includes('alpha') ? 1 : 0, text.includes('beta') ? 1 : 0];
}

function makeEnv(vectorize: FakeVectorize, db: D1Database = {
  prepare: () => ({ first: async () => ({ ok: 1 }) }),
} as unknown as D1Database, vectorizeSmall?: FakeVectorize): Env {
  return {
    RAG_SERVICE_KEYS: JSON.stringify({ 'key-a': 'tenant-a', 'key-b': 'tenant-b' }),
    EMBEDDING_MODEL: '@cf/baai/bge-base-en-v1.5',
    EMBEDDING_MODEL_SMALL: '@cf/baai/bge-small-en-v1.5',
    VECTORIZE: vectorize,
    ...(vectorizeSmall ? { VECTORIZE_SMALL: vectorizeSmall } : {}),
    AI: {
      run: async (model: string, input: { text: string[] }) => ({
        data: input.text.map((text) => model.includes('small') ? vectorFor(`${text} small`) : vectorFor(text)),
      }),
    } as unknown as Ai,
    DB: db,
  };
}

describe('rag-service app', () => {
  it('rejects requests without a service key', async () => {
    const repo = new MemoryRepository();
    const app = createApp({ makeRepository: () => repo });
    const res = await app.request('/v1/indexes', {}, makeEnv(new FakeVectorize()));

    expect(res.status).toBe(401);
  });

  it('ingests documents into chunk rows and Vectorize, then hydrates query results', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const app = createApp({ makeRepository: () => repo });
    const env = makeEnv(vectorize);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Docs' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;

    const ingest = await app.request(
      `/v1/indexes/${index.id}/ingest`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          documents: [{ content: 'alpha document\n\nbeta appendix', metadata: { source: 'unit' } }],
          chunking: { size: 18, overlap: 4 },
        }),
      },
      env,
    );

    expect(ingest.status).toBe(201);
    expect(repo.chunks.size).toBeGreaterThan(0);
    expect(vectorize.vectors.size).toBe(repo.chunks.size);

    const query = await app.request(
      `/v1/indexes/${index.id}/query`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ query: 'alpha', top_k: 3 }),
      },
      env,
    );
    const result = (await query.json()) as { data: Array<{ chunk_content: string; metadata: JsonRecord }> };

    expect(query.status).toBe(200);
    expect(result.data.length).toBeGreaterThan(0);
    expect(result.data[0]?.chunk_content).toContain('alpha');
    expect(result.data[0]?.metadata).toEqual({ source: 'unit' });
  });

  it('can ingest and query the small semantic Vectorize index by namespace', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const vectorizeSmall = new FakeVectorize();
    const app = createApp({ makeRepository: () => repo });
    const env = makeEnv(vectorize, undefined as unknown as D1Database, vectorizeSmall);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Small Docs' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;
    await app.request(
      `/v1/indexes/${index.id}/ingest`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ documents: [{ content: 'alpha semantic document' }] }),
      },
      env,
    );

    const query = await app.request(
      `/v1/indexes/${index.id}/query`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ query: 'semantic alpha', top_k: 1, mode: 'semantic', semantic_model: 'small' }),
      },
      env,
    );
    const timing = JSON.parse(query.headers.get('X-RAG-Timing') ?? '{}');

    expect(query.status).toBe(200);
    expect(vectorizeSmall.vectors.size).toBe(repo.chunks.size);
    expect(timing).toMatchObject({ semantic_model: 'small', vectorize_path: 'namespace' });
    expect(vectorizeSmall.queries.at(-1)).toMatchObject({
      namespace: `tenant-a:${index.id}`,
      returnMetadata: 'all',
    });
  });

  it('caches repeated text queries before calling AI or Vectorize again', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    let aiCalls = 0;
    let vectorQueries = 0;
    const originalQuery = vectorize.query.bind(vectorize);
    vectorize.query = async (...args) => {
      vectorQueries += 1;
      return originalQuery(...args);
    };
    const app = createApp({
      makeRepository: () => repo,
      queryCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embeddingCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embed: async (_env, texts) => {
        aiCalls += 1;
        return texts.map(vectorFor);
      },
    });
    const env = makeEnv(vectorize);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Cached Docs' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;
    await app.request(
      `/v1/indexes/${index.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          chunks: [
            {
              id: 'chunk-cache',
              document_id: 'doc-cache',
              document_content: 'alpha cache document',
              content: 'alpha cache document',
              embedding: vectorFor('alpha'),
              chunk_index: 0,
            },
          ],
        }),
      },
      env,
    );

    const first = await app.request(
      `/v1/indexes/${index.id}/query`,
      { method: 'POST', headers: auth, body: JSON.stringify({ query: 'alpha', top_k: 1, mode: 'semantic' }) },
      env,
    );
    const second = await app.request(
      `/v1/indexes/${index.id}/query`,
      { method: 'POST', headers: auth, body: JSON.stringify({ top_k: 1, query: 'alpha', mode: 'semantic' }) },
      env,
    );

    expect(first.headers.get('X-RAG-Cache')).toBe('miss');
    expect(second.headers.get('X-RAG-Cache')).toBe('hit');
    expect(JSON.parse(first.headers.get('X-RAG-Timing') ?? '{}')).toMatchObject({
      cache: 'miss',
      embedding_cache: 'miss',
      route: 'query',
    });
    expect(JSON.parse(second.headers.get('X-RAG-Timing') ?? '{}')).toMatchObject({
      cache: 'hit',
      route: 'query',
    });
    expect(first.headers.get('Server-Timing')).toContain('rag_total');
    expect(aiCalls).toBe(1);
    expect(vectorQueries).toBe(1);
  });

  it('uses lexical retrieval for exact non-cache text queries without AI or Vectorize', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const db = new FakeQueryCacheD1();
    let aiCalls = 0;
    let vectorQueries = 0;
    const originalQuery = vectorize.query.bind(vectorize);
    vectorize.query = async (...args) => {
      vectorQueries += 1;
      return originalQuery(...args);
    };
    const app = createApp({
      makeRepository: () => repo,
      embed: async (_env, texts) => {
        aiCalls += 1;
        return texts.map(vectorFor);
      },
    });
    const env = makeEnv(vectorize, db as unknown as D1Database);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Lexical Docs' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;
    await app.request(
      `/v1/indexes/${index.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          chunks: [{
            id: 'chunk-lexical',
            document_id: 'doc-lexical',
            document_content: 'billing guardrails are documented here',
            content: 'billing guardrails are documented here',
            embedding: vectorFor('unrelated'),
            chunk_index: 0,
          }],
        }),
      },
      env,
    );

    repo.getIndexCalls = 0;
    db.selectPayloadCalls = 0;
    const query = await app.request(
      `/v1/indexes/${index.id}/query`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ query: 'where are billing guardrails documented?', top_k: 1 }),
      },
      env,
    );
    const result = (await query.json()) as { data: Array<{ chunk_content: string }> };
    const timing = JSON.parse(query.headers.get('X-RAG-Timing') ?? '{}');

    expect(query.status).toBe(200);
    expect(query.headers.get('X-RAG-Cache')).toBe('miss');
    expect(timing).toMatchObject({ retrieval: 'lexical' });
    expect(result.data[0]?.chunk_content).toContain('billing guardrails');
    expect(aiCalls).toBe(0);
    expect(vectorQueries).toBe(0);
    expect(repo.getIndexCalls).toBe(0);
    expect(db.selectPayloadCalls).toBe(0);
  });

  it('benchmarks warmed text queries inside the Worker', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    let aiCalls = 0;
    let vectorQueries = 0;
    const originalQuery = vectorize.query.bind(vectorize);
    vectorize.query = async (...args) => {
      vectorQueries += 1;
      return originalQuery(...args);
    };
    const app = createApp({
      makeRepository: () => repo,
      queryCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embeddingCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embed: async (_env, texts) => {
        aiCalls += 1;
        return texts.map(vectorFor);
      },
    });
    const env = makeEnv(vectorize);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Bench Docs' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;
    await app.request(
      `/v1/indexes/${index.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          chunks: [
            {
              id: 'chunk-bench',
              document_id: 'doc-bench',
              document_content: 'alpha benchmark document',
              content: 'alpha benchmark document',
              embedding: vectorFor('alpha'),
              chunk_index: 0,
            },
          ],
        }),
      },
      env,
    );

    const bench = await app.request(
      `/v1/indexes/${index.id}/benchmark-query`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ queries: ['alpha'], warmup: 1, repeat: 3, top_k: 1, mode: 'semantic' }),
      },
      env,
    );
    const result = (await bench.json()) as {
      cache_hit_rate: number;
      latency: { count: number; p95_ms: number; p99_ms: number };
      measurements: Array<{ cache: string; result_count: number }>;
    };

    expect(bench.status).toBe(200);
    expect(result.latency.count).toBe(3);
    expect(result.latency).toHaveProperty('p99_ms');
    expect(result.cache_hit_rate).toBe(1);
    expect(result.measurements).toHaveLength(3);
    expect(result.measurements.every((row) => row.cache === 'hit' && row.result_count === 1)).toBe(true);
    expect(aiCalls).toBe(1);
    expect(vectorQueries).toBe(1);
  });

  it('uses the shared D1 query cache across app instances', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const db = new FakeQueryCacheD1();
    let aiCalls = 0;
    let vectorQueries = 0;
    const originalQuery = vectorize.query.bind(vectorize);
    vectorize.query = async (...args) => {
      vectorQueries += 1;
      return originalQuery(...args);
    };
    const embed = async (_env: Env, texts: string[]) => {
      aiCalls += 1;
      return texts.map(vectorFor);
    };
    const env = makeEnv(vectorize, db as unknown as D1Database);
    env.RAG_SHARED_QUERY_CACHE_ENABLED = 'true';
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };
    const firstApp = createApp({
      makeRepository: () => repo,
      queryCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embeddingCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embed,
    });

    const created = await firstApp.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Shared Cache Docs' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;
    await firstApp.request(
      `/v1/indexes/${index.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          chunks: [{
            id: 'chunk-shared-cache',
            document_id: 'doc-shared-cache',
            document_content: 'alpha shared cache document',
            content: 'alpha shared cache document',
            embedding: vectorFor('alpha'),
            chunk_index: 0,
          }],
        }),
      },
      env,
    );
    const firstQuery = await firstApp.request(
      `/v1/indexes/${index.id}/query`,
      { method: 'POST', headers: auth, body: JSON.stringify({ query: 'alpha', top_k: 1, mode: 'semantic' }) },
      env,
    );

    const secondApp = createApp({
      makeRepository: () => repo,
      queryCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embeddingCache: new TtlCache({ enabled: true, ttlMs: 60_000, maxEntries: 100 }),
      embed,
    });
    const secondQuery = await secondApp.request(
      `/v1/indexes/${index.id}/query`,
      { method: 'POST', headers: auth, body: JSON.stringify({ query: 'alpha', top_k: 1, mode: 'semantic' }) },
      env,
    );

    expect(firstQuery.headers.get('X-RAG-Cache')).toBe('miss');
    expect(secondQuery.headers.get('X-RAG-Cache')).toBe('hit');
    expect(JSON.parse(secondQuery.headers.get('X-RAG-Timing') ?? '{}')).toMatchObject({
      cache_layer: 'd1',
    });
    expect(aiCalls).toBe(1);
    expect(vectorQueries).toBe(1);
  });

  it('prevents a tenant from querying another tenant index', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const app = createApp({ makeRepository: () => repo });
    const env = makeEnv(vectorize);

    const created = await app.request(
      '/v1/indexes',
      {
        method: 'POST',
        headers: { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: 'Private' }),
      },
      env,
    );
    const index = (await created.json()) as IndexRecord;

    const query = await app.request(
      `/v1/indexes/${index.id}/query-vector`,
      {
        method: 'POST',
        headers: { Authorization: 'Bearer key-b', 'Content-Type': 'application/json' },
        body: JSON.stringify({ vector: [1, 0, 0] }),
      },
      env,
    );

    expect(query.status).toBe(404);
  });

  it('does not let caller filters override server tenant and index scope', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const app = createApp({ makeRepository: () => repo });
    const env = makeEnv(vectorize);
    const authA = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };
    const authB = { Authorization: 'Bearer key-b', 'Content-Type': 'application/json' };

    const indexA = (await (await app.request(
      '/v1/indexes',
      { method: 'POST', headers: authA, body: JSON.stringify({ name: 'Tenant A' }) },
      env,
    )).json()) as IndexRecord;
    const indexB = (await (await app.request(
      '/v1/indexes',
      { method: 'POST', headers: authB, body: JSON.stringify({ name: 'Tenant B' }) },
      env,
    )).json()) as IndexRecord;

    await app.request(
      `/v1/indexes/${indexA.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: authA,
        body: JSON.stringify({
          chunks: [{
            id: 'chunk-a',
            document_id: 'doc-a',
            document_content: 'tenant a document',
            content: 'tenant a secret',
            embedding: [10, 0, 0],
            chunk_index: 0,
          }],
        }),
      },
      env,
    );
    await app.request(
      `/v1/indexes/${indexB.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: authB,
        body: JSON.stringify({
          chunks: [{
            id: 'chunk-b',
            document_id: 'doc-b',
            document_content: 'tenant b document',
            content: 'tenant b visible',
            embedding: [1, 0, 0],
            chunk_index: 0,
          }],
        }),
      },
      env,
    );

    const query = await app.request(
      `/v1/indexes/${indexB.id}/query-vector`,
      {
        method: 'POST',
        headers: authB,
        body: JSON.stringify({
          vector: [1, 0, 0],
          filter: { tenant: 'tenant-a', index_id: indexA.id },
        }),
      },
      env,
    );
    const result = (await query.json()) as { data: Array<{ chunk_content: string }> };

    expect(query.status).toBe(200);
    expect(result.data).toHaveLength(1);
    expect(result.data[0]?.chunk_content).toBe('tenant b visible');
    expect(vectorize.queries.at(-1)).toMatchObject({
      namespace: `tenant-b:${indexB.id}`,
      returnMetadata: 'all',
    });
    expect(vectorize.queries.at(-1)?.filter).toBeUndefined();
  });

  it('uses the index existence cache for queries after creating an index', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    const app = createApp({ makeRepository: () => repo });
    const env = makeEnv(vectorize);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Cached Index' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;
    await app.request(
      `/v1/indexes/${index.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          chunks: [{
            id: 'chunk-index-cache',
            document_id: 'doc-index-cache',
            document_content: 'alpha cache document',
            content: 'alpha cache document',
            embedding: [1, 1, 0],
            chunk_index: 0,
          }],
        }),
      },
      env,
    );

    repo.getIndexCalls = 0;
    const query = await app.request(
      `/v1/indexes/${index.id}/query-vector`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ vector: [1, 1, 0], top_k: 1 }),
      },
      env,
    );

    expect(query.status).toBe(200);
    expect(repo.getIndexCalls).toBe(0);
  });

  it('accepts pre-embedded chunks for backfill without calling AI', async () => {
    const repo = new MemoryRepository();
    const vectorize = new FakeVectorize();
    let embedCalls = 0;
    const app = createApp({
      makeRepository: () => repo,
      embed: async () => {
        embedCalls += 1;
        return [];
      },
    });
    const env = makeEnv(vectorize);
    const auth = { Authorization: 'Bearer key-a', 'Content-Type': 'application/json' };

    const created = await app.request(
      '/v1/indexes',
      { method: 'POST', headers: auth, body: JSON.stringify({ name: 'Backfill' }) },
      env,
    );
    const index = (await created.json()) as IndexRecord;

    const backfill = await app.request(
      `/v1/indexes/${index.id}/ingest-vectors`,
      {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({
          chunks: [
            {
              id: 'chunk-1',
              document_id: 'doc-1',
              document_content: 'alpha original document',
              content: 'alpha original',
              embedding: [1, 1, 0],
              chunk_index: 0,
              metadata: { imported: true },
            },
          ],
        }),
      },
      env,
    );

    expect(backfill.status).toBe(201);
    expect(await backfill.json()).toEqual({ upserted: 1 });
    expect(embedCalls).toBe(0);
    expect(repo.documents.get('doc-1')?.content).toBe('alpha original document');
    expect(repo.chunks.get('chunk-1')?.metadata).toEqual({ imported: true });
    expect(vectorize.vectors.get('chunk-1')?.values).toEqual([1, 1, 0]);
  });
});
