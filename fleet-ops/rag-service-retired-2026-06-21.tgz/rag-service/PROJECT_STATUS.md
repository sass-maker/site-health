# rag-service — PROJECT STATUS

Last updated: 2026-06-20

## Why / What

Standalone Cloudflare Worker RAG service for fleet vector ingestion and retrieval. Owns tenant-scoped indexes, document ingest, lexical and semantic query, optional SaaS Maker D1 export import, and service-binding latency benchmarks behind service-key auth.

**Users:** Fleet app developers integrating via Cloudflare service bindings (`RAG_SERVICE` + `RAG_SERVICE_KEY`); operators running backfill, benchmarks, and deploy readiness.

**Constraints:** Tenant isolation enforced on all index/query operations; fleet callers should prefer service bindings over public HTTP. Semantic fuzzy latency targets apply to binding-local paths, not laptop-to-`workers.dev` RTT.

**IN scope:** `/v1/*` CRUD, ingest, query, Vectorize + D1 storage, Workers AI embeddings, optional SaaS Maker export backfill scripts, Linkchat/Starboard fleet wiring.

**OUT of scope:** SaaS Maker control-plane knowledge/RAG (removed from saas-maker 2026-06-20 — not delegated from that API), per-project key rotation UI, queue/workflow ingestion at scale, reranking beyond lexical auto-path, AI Gateway cache (blocked on Wrangler OAuth).

Primary consumers: **Linkchat** and **Starboard**. SaaS Maker is no longer a RAG consumer after in-API knowledge removal.

## Dependencies

### External

- **Cloudflare Workers:** Hono 4.12 · TypeScript 6 · Vitest 4.
- **Cloudflare D1:** `rag-db` — indexes, documents, chunks, query cache.
- **Cloudflare Vectorize:** `rag-bge-768` + `rag-bge-small-384` with metadata indexes on `tenant` and `index_id`.
- **Cloudflare R2:** `rag-raw-docs` for optional raw document blobs.
- **Workers AI embeddings:** `@cf/baai/bge-base-en-v1.5`, `@cf/baai/bge-small-en-v1.5`.
- **Env / secrets:** `RAG_SERVICE_KEYS` secret is JSON map `{ "<random-key>": "<tenant-name>" }`. Never commit real keys. Wrangler vars: `RAG_CACHE_*`.
- **One-time bootstrap:** `wrangler vectorize create rag-bge-768 ...`, `wrangler d1 create rag-db`, `wrangler d1 migrations apply rag-db`, `wrangler r2 bucket create rag-raw-docs`, `wrangler secret put RAG_SERVICE_KEYS`.

### Internal (fleet)

| Consumer | Integration |
| --- | --- |
| **Linkchat** | `RAG_SERVICE` service binding + `RAG_SERVICE_KEY`; legacy knowledgebase Worker URL fallback |
| **Starboard** | `RAG_SERVICE` binding + `RAG_SERVICE_KEY` + `STARBOARD_RAG_INDEX_ID`; Turso embeddings remain fallback |
| **SaaS Maker** | **Not a consumer** after 2026-06-20 knowledge removal. Legacy `scripts/backfill-saas-maker.mjs` remains for one-off D1 export import only. Secret audit: `cd ../saas-maker && pnpm fleet:secret-audit -- --project rag-service` |

### Stack & commands

| Command | Purpose |
| --- | --- |
| `pnpm install` | Install deps |
| `pnpm check` | typecheck + vitest |
| `pnpm dev` | `wrangler dev --local` |
| `pnpm run backfill:dry-run` | Dry-run migration fixtures |
| `pnpm run benchmark:dry-run` | Dry-run benchmark fixtures |
| `pnpm run smoke:export:dry-run` | Dry-run export smoke |
| `pnpm run readiness` | Deployed health + auth gate |
| `RAG_SERVICE_KEY=<key> pnpm run readiness:auth` | Authenticated readiness |
| `pnpm deploy` | Production deploy |

**Entrypoints:** `src/index.ts` · `src/service-bench.ts` · `wrangler.jsonc` · `scripts/backfill-saas-maker.mjs` · `scripts/benchmark-rag.mjs` · `scripts/deploy-readiness.mjs` · `scripts/smoke-saas-maker-export.mjs` · `tests/*.test.ts`.

**Optional legacy backfill example (SaaS Maker D1 export — not an active integration):**

```bash
RAG_BASE_URL=https://rag-service.sarthakagrawal927.workers.dev \
RAG_SERVICE_KEY=<key> \
node scripts/backfill-saas-maker.mjs \
  --input saas-maker-chunks.json \
  --index-name "Legacy export" \
  --external-id <legacy-index-id>
```

**Latency benchmark:**

```bash
RAG_BASE_URL=... RAG_SERVICE_KEY=<key> \
node scripts/benchmark-rag.mjs --input fixtures/benchmark.sample.json --repeat 5 --top-k 5
```

## Timeline

- **2026-06-20** — SaaS Maker removed in-API `/v1/knowledge/*` and RAG bindings; rag-service continues as a standalone fleet service for Linkchat and Starboard only.
- **Prior cutover verification** — Deployed health, authenticated readiness, exported-vector smoke, raw-document ingest/query benchmarks completed. Production SaaS Maker knowledge tables were empty — no real backfill was required.

## Products

| Surface | URL |
| --- | --- |
| Deployed Worker (health + API) | `https://rag-service.sarthakagrawal927.workers.dev` |
| Health (unauthenticated) | `GET /v1/healthz` |
| Protected API | `POST/GET/DELETE /v1/indexes/*`, ingest, query, query-vector, benchmark |
| Service-binding bench Worker | `src/service-bench.ts` — binding-local p50/p95/p99 targets separate from public Internet RTT |

Custom domain not configured.

## Features (shipped)

- Tenant-scoped index CRUD with service-key auth (`X-RAG-Service-Key` → tenant name).
- Document ingest (text + metadata), chunking, embedding via Workers AI, Vectorize upsert.
- Lexical query path; semantic query via Vectorize + optional in-memory query cache.
- `X-RAG-Timing` / `Server-Timing` on query responses.
- In-Worker benchmark route; JSON benchmark script with p50/p95/p99 reporting.
- Deploy readiness harness: health, auth gate, optional exported-vector smoke via `deploy-readiness.mjs`.
- Service-binding bench Worker for binding-local latency (targets: warmed cache p95 <100 ms / p99 <300 ms).

### Fleet wiring

- Linkchat and Starboard prefer shared RAG via bindings with legacy fallback paths.
- SaaS Maker API no longer exposes knowledge routes or RAG bindings (2026-06-20).
- Fleet secret audit and contract checks registered in saas-maker.

## Todo / Planned / Deferred / Blocked

### Planned

1. For latency-critical fuzzy UX: prefer cached/normalized queries, `query-vector` with precomputed embeddings, or lexical/hybrid fallback — unique semantic misses still exceed p99 <300 ms on cold Workers AI + Vectorize outliers.
2. Decide whether shared query-cache persistence should move beyond per-isolate memory (KV/D1 vs Cloudflare Cache API tradeoffs).
3. Keep public laptop-to-`workers.dev` numbers separate from Cloudflare service-binding targets.

### Deferred

- Per-project service key rotation UI/API.
- Queue/Workflow-based ingestion for large documents.
- Reranking and hybrid lexical+semantic retrieval beyond current lexical auto-path.
- Broader fleet project onboarding beyond Linkchat and Starboard.
- Semantic fuzzy query p99 latency still exceeds 300 ms on cold/outlier Workers AI + Vectorize paths despite p95 improvements.
- First-request cold starts can exceed latency targets even on the lexical path.
- Public Internet RTT to the Worker remains higher than service-binding latency and is not representative of bound calls.

### Blocked

- AI Gateway cache for Workers AI (implemented but not enabled — gateway creation blocked on Wrangler OAuth auth).
