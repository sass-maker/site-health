import { Hono, type Context } from 'hono';
import { requireServiceKey, type Variables } from './auth';
import { parseCacheOptions, stableStringify, TtlCache } from './cache';
import { chunkText } from './chunk';
import { D1Repository } from './d1-repository';
import { embedTexts } from './embeddings';
import type { CreateChunkInput, Repository } from './repository';
import type { ChunkRecord, Env, JsonRecord, SearchResult, VectorizeVector } from './types';

const MAX_DOC_SIZE = 1_000_000;
const MAX_TOP_K = 50;
const MAX_LEXICAL_CHUNKS = 5000;
const MAX_BENCHMARK_QUERIES = 20;
const MAX_BENCHMARK_REPEAT = 200;
const MAX_BENCHMARK_WARMUP = 20;
const DEFAULT_BASE_EMBEDDING_MODEL = '@cf/baai/bge-base-en-v1.5';
const DEFAULT_SMALL_EMBEDDING_MODEL = '@cf/baai/bge-small-en-v1.5';
const STOP_WORDS = new Set([
  'a',
  'an',
  'and',
  'are',
  'for',
  'from',
  'how',
  'the',
  'this',
  'that',
  'what',
  'when',
  'where',
  'which',
  'with',
]);
type AppContext = Context<{ Bindings: Env; Variables: Variables }>;
type QueryPayload = { data: SearchResult[] };
type TimingValue = number | string | boolean;
type RagTiming = Record<string, TimingValue>;
type CacheStatus = 'hit' | 'miss';
type SemanticModel = 'base' | 'small';

interface AppOptions {
  makeRepository?: (env: Env) => Repository;
  embed?: typeof embedTexts;
  queryCache?: TtlCache<QueryPayload>;
  embeddingCache?: TtlCache<number[]>;
  indexCache?: TtlCache<boolean>;
  lexicalChunkCache?: TtlCache<ChunkRecord[]>;
}

interface CreateIndexBody {
  name?: string;
  external_id?: string;
}

interface IngestBody {
  documents?: Array<{
    external_id?: string;
    content?: string;
    metadata?: JsonRecord;
  }>;
  chunking?: {
    size?: number;
    overlap?: number;
  };
}

interface QueryBody {
  query?: string;
  vector?: number[];
  top_k?: number;
  filter?: JsonRecord;
  min_score?: number;
  mode?: 'auto' | 'semantic' | 'lexical';
  semantic_model?: SemanticModel;
}

interface BenchmarkQueryBody {
  queries?: string[];
  repeat?: number;
  warmup?: number;
  top_k?: number;
  filter?: JsonRecord;
  min_score?: number;
  mode?: 'auto' | 'semantic' | 'lexical';
  semantic_model?: SemanticModel;
}

interface IngestVectorsBody {
  chunks?: Array<{
    id?: string;
    document_id?: string;
    document_content?: string;
    document_external_id?: string;
    content?: string;
    embedding?: number[];
    chunk_index?: number;
    metadata?: JsonRecord;
  }>;
}

function jsonRecord(value: unknown): JsonRecord {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as JsonRecord) : {};
}

function clampTopK(value: unknown): number {
  const parsed = typeof value === 'number' ? value : Number(value || 5);
  if (!Number.isFinite(parsed)) return 5;
  return Math.min(Math.max(Math.trunc(parsed), 1), MAX_TOP_K);
}

function sortResultsByVectorOrder(ids: string[], rows: ChunkRecord[]): ChunkRecord[] {
  const byId = new Map(rows.map((row) => [row.id, row]));
  return ids.map((id) => byId.get(id)).filter((row): row is ChunkRecord => Boolean(row));
}

function buildCacheKey(parts: unknown): string {
  return stableStringify(parts);
}

function vectorNamespace(tenant: string, indexId: string): string {
  return `${tenant}:${indexId}`;
}

function semanticModelFromBody(body: QueryBody): SemanticModel {
  return body.semantic_model === 'small' ? 'small' : 'base';
}

function embeddingModel(env: Env, model: SemanticModel): string {
  if (model === 'small') return env.EMBEDDING_MODEL_SMALL || DEFAULT_SMALL_EMBEDDING_MODEL;
  return env.EMBEDDING_MODEL || DEFAULT_BASE_EMBEDDING_MODEL;
}

function vectorizeBinding(env: Env, model: SemanticModel) {
  return model === 'small' && env.VECTORIZE_SMALL ? env.VECTORIZE_SMALL : env.VECTORIZE;
}

function userVectorFilter(filter: unknown): JsonRecord | undefined {
  const record = { ...jsonRecord(filter) };
  delete record.tenant;
  delete record.index_id;
  return Object.keys(record).length > 0 ? record : undefined;
}

function sharedQueryCacheEnabled(env: Env): boolean {
  return env.RAG_SHARED_QUERY_CACHE_ENABLED === 'true';
}

function vectorMetadata(
  tenant: string,
  indexId: string,
  documentId: string,
  chunkIndex: number,
  content: string,
  metadata: JsonRecord,
): JsonRecord {
  return {
    tenant,
    index_id: indexId,
    document_id: documentId,
    chunk_index: chunkIndex,
    chunk_content: content,
    chunk_metadata: JSON.stringify(metadata),
  };
}

function searchResultFromVectorMetadata(match: { id: string; score: number; metadata?: JsonRecord }): SearchResult | null {
  const metadata = match.metadata ?? {};
  if (typeof metadata.document_id !== 'string' || typeof metadata.chunk_content !== 'string') return null;
  let parsedMetadata: unknown = {};
  if (typeof metadata.chunk_metadata === 'string') {
    try {
      parsedMetadata = JSON.parse(metadata.chunk_metadata) as unknown;
    } catch {
      parsedMetadata = {};
    }
  }
  return {
    document_id: metadata.document_id,
    chunk_id: match.id,
    chunk_content: metadata.chunk_content,
    score: match.score,
    metadata: jsonRecord(parsedMetadata),
  };
}

function tokenizeLexicalQuery(query: string): string[] {
  const tokens = query
    .toLowerCase()
    .match(/[a-z0-9][a-z0-9-]{2,}/g);
  if (!tokens) return [];
  return Array.from(new Set(tokens.filter((token) => !STOP_WORDS.has(token)))).slice(0, 8);
}

function normalizeSemanticQuery(query: string): string {
  return query
    .trim()
    .toLowerCase()
    .replace(/[?!.,;:]+$/g, '')
    .replace(/\s+/g, ' ');
}

function elapsedMs(started: number): number {
  return Math.round((performance.now() - started) * 100) / 100;
}

function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.ceil((p / 100) * sorted.length) - 1);
  return sorted[index] ?? 0;
}

function summarizeLatencies(samples: number[]) {
  const sorted = [...samples].sort((a, b) => a - b);
  const total = sorted.reduce((sum, value) => sum + value, 0);
  return {
    count: sorted.length,
    min_ms: Math.round((sorted[0] ?? 0) * 100) / 100,
    p50_ms: Math.round(percentile(sorted, 50) * 100) / 100,
    p95_ms: Math.round(percentile(sorted, 95) * 100) / 100,
    p99_ms: Math.round(percentile(sorted, 99) * 100) / 100,
    max_ms: Math.round((sorted.at(-1) ?? 0) * 100) / 100,
    mean_ms: Math.round((sorted.length ? total / sorted.length : 0) * 100) / 100,
  };
}

function isQueryPayload(value: unknown): value is QueryPayload {
  return Boolean(value && typeof value === 'object' && Array.isArray((value as QueryPayload).data));
}

function withTimingHeaders(
  timing: RagTiming,
  cache: CacheStatus,
  started: number,
): Record<string, string> {
  timing.cache = cache;
  timing.total_ms = elapsedMs(started);
  const serverTiming = Object.entries(timing)
    .filter((entry): entry is [string, number] => entry[0].endsWith('_ms') && typeof entry[1] === 'number')
    .map(([key, value]) => `rag_${key.slice(0, -3)};dur=${value}`)
    .join(', ');
  return {
    'X-RAG-Cache': cache,
    'X-RAG-Timing': JSON.stringify(timing),
    'Server-Timing': serverTiming,
  };
}

async function deleteVectors(env: Env, ids: string[], model: SemanticModel = 'base'): Promise<void> {
  if (ids.length === 0) return;
  const binding = vectorizeBinding(env, model);
  for (let start = 0; start < ids.length; start += 1000) {
    await binding.deleteByIds(ids.slice(start, start + 1000));
  }
}

export function createApp(options: AppOptions = {}) {
  const app = new Hono<{ Bindings: Env; Variables: Variables }>();
  const makeRepository = options.makeRepository ?? ((env: Env) => new D1Repository(env.DB));
  const embed = options.embed ?? embedTexts;
  const queryCache = options.queryCache ?? new TtlCache<QueryPayload>(parseCacheOptions({}));
  const embeddingCache = options.embeddingCache ?? new TtlCache<number[]>(parseCacheOptions({}));
  const indexCache = options.indexCache ?? new TtlCache<boolean>(parseCacheOptions({}));
  const lexicalChunkCache = options.lexicalChunkCache ?? new TtlCache<ChunkRecord[]>(parseCacheOptions({}));

  function rememberIndex(env: Env, tenant: string, indexId: string): void {
    indexCache.configure(parseCacheOptions(env));
    indexCache.set(buildCacheKey({ tenant, indexId }), true);
  }

  async function indexExists(env: Env, repo: Repository, tenant: string, indexId: string): Promise<boolean> {
    indexCache.configure(parseCacheOptions(env));
    const key = buildCacheKey({ tenant, indexId });
    if (indexCache.get(key)) return true;
    const index = await repo.getIndex(tenant, indexId);
    if (!index) return false;
    indexCache.set(key, true);
    return true;
  }

  async function embedOne(
    env: Env,
    tenant: string,
    text: string,
    model: SemanticModel,
    timing?: RagTiming,
  ): Promise<number[]> {
    const started = performance.now();
    embeddingCache.configure(parseCacheOptions(env));
    const modelId = embeddingModel(env, model);
    const key = buildCacheKey({ model: modelId, tenant, text });
    const cached = embeddingCache.get(key);
    if (cached) {
      if (timing) {
        timing.embedding_cache = 'hit';
        timing.embedding_model = model;
        timing.embed_ms = elapsedMs(started);
      }
      return cached;
    }
    const [vector] = await embed(env, [text], { model: modelId });
    if (!vector) throw new Error('Embedding response was empty');
    embeddingCache.set(key, vector);
    if (timing) {
      timing.embedding_cache = 'miss';
      timing.embedding_model = model;
      timing.embed_ms = elapsedMs(started);
    }
    return vector;
  }

  async function getSharedQueryCache(
    env: Env,
    tenant: string,
    indexId: string,
    cacheKey: string,
    timing?: RagTiming,
  ): Promise<QueryPayload | null> {
    if (!sharedQueryCacheEnabled(env)) return null;
    if (!parseCacheOptions(env).enabled) return null;
    const started = performance.now();
    try {
      const row = await env.DB
        .prepare(
          `SELECT payload
             FROM query_cache
            WHERE cache_key = ? AND tenant = ? AND index_id = ? AND expires_at > ?`,
        )
        .bind(cacheKey, tenant, indexId, Date.now())
        .first<{ payload: string }>();
      if (!row?.payload) return null;
      const parsed = JSON.parse(row.payload) as unknown;
      return isQueryPayload(parsed) ? parsed : null;
    } catch {
      return null;
    } finally {
      if (timing) timing.shared_cache_ms = elapsedMs(started);
    }
  }

  async function setSharedQueryCache(
    env: Env,
    tenant: string,
    indexId: string,
    cacheKey: string,
    payload: QueryPayload,
  ): Promise<void> {
    if (!sharedQueryCacheEnabled(env)) return;
    const cacheOptions = parseCacheOptions(env);
    if (!cacheOptions.enabled) return;
    try {
      await env.DB
        .prepare(
          `INSERT OR REPLACE INTO query_cache (cache_key, tenant, index_id, payload, expires_at)
           VALUES (?, ?, ?, ?, ?)`,
        )
        .bind(cacheKey, tenant, indexId, JSON.stringify(payload), Date.now() + cacheOptions.ttlMs)
        .run();
    } catch {
      // Query caching is an optimization. A missing migration or transient D1 write failure should not fail search.
    }
  }

  async function clearSharedQueryCache(env: Env, tenant: string, indexId: string): Promise<void> {
    try {
      await env.DB
        .prepare('DELETE FROM query_cache WHERE tenant = ? AND index_id = ?')
        .bind(tenant, indexId)
        .run();
    } catch {
      // Best effort cache invalidation; in-memory cache is cleared separately.
    }
  }

  function persistSharedQueryCache(
    c: AppContext,
    tenant: string,
    indexId: string,
    cacheKey: string,
    payload: QueryPayload,
  ): Promise<void> | undefined {
    const promise = setSharedQueryCache(c.env, tenant, indexId, cacheKey, payload);
    try {
      c.executionCtx.waitUntil(promise);
      return undefined;
    } catch {
      return promise;
    }
  }

  async function getCachedLexicalChunks(
    env: Env,
    repo: Repository,
    tenant: string,
    indexId: string,
    timing?: RagTiming,
  ): Promise<ChunkRecord[]> {
    const started = performance.now();
    lexicalChunkCache.configure(parseCacheOptions(env));
    const key = buildCacheKey({ tenant, indexId });
    const cached = lexicalChunkCache.get(key);
    if (cached) {
      if (timing) {
        timing.lexical_chunk_cache = 'hit';
        timing.lexical_chunk_load_ms = elapsedMs(started);
      }
      return cached;
    }
    const chunks = await repo.listChunksForIndex(tenant, indexId, MAX_LEXICAL_CHUNKS);
    lexicalChunkCache.set(key, chunks);
    if (timing) {
      timing.lexical_chunk_cache = 'miss';
      timing.lexical_chunk_load_ms = elapsedMs(started);
    }
    return chunks;
  }

  function clearLexicalChunkCache(tenant: string, indexId: string): void {
    lexicalChunkCache.configure(parseCacheOptions({}));
    lexicalChunkCache.set(buildCacheKey({ tenant, indexId }), []);
    lexicalChunkCache.clear();
  }

  async function runTextQuery(c: AppContext, query: string, body: QueryBody): Promise<{
    payload: QueryPayload;
    cache: CacheStatus;
    timing: RagTiming;
  }> {
    const started = performance.now();
    const timing: RagTiming = { route: 'query' };
    const tenant = c.get('tenant');
    const normalizedQuery = normalizeSemanticQuery(query);
    const semanticModel = semanticModelFromBody(body);
    const cacheKey = buildCacheKey({
      tenant,
      indexId: c.req.param('id'),
      query: normalizedQuery,
      topK: clampTopK(body.top_k),
      filter: jsonRecord(body.filter),
      minScore: typeof body.min_score === 'number' ? body.min_score : null,
      mode: body.mode ?? 'auto',
      semanticModel,
    });
    const indexId = c.req.param('id');
    if (!indexId) throw new Error('Index not found');
    queryCache.configure(parseCacheOptions(c.env));
    const cached = queryCache.get(cacheKey);
    if (cached) {
      timing.cache_layer = 'memory';
      timing.cache = 'hit';
      timing.total_ms = elapsedMs(started);
      return { payload: cached, cache: 'hit', timing };
    }
    if (body.mode !== 'semantic') {
      const lexical = await queryByLexical(c, query, body, timing);
      if (lexical && lexical.data.length > 0) {
        queryCache.set(cacheKey, lexical);
        timing.cache = 'miss';
        timing.total_ms = elapsedMs(started);
        return { payload: lexical, cache: 'miss', timing };
      }
      if (body.mode === 'lexical') {
        const empty = { data: [] };
        timing.cache = 'miss';
        timing.total_ms = elapsedMs(started);
        return { payload: empty, cache: 'miss', timing };
      }
    }
    const sharedCached = await getSharedQueryCache(c.env, tenant, indexId, cacheKey, timing);
    if (sharedCached) {
      timing.cache_layer = 'd1';
      queryCache.set(cacheKey, sharedCached);
      timing.cache = 'hit';
      timing.total_ms = elapsedMs(started);
      return { payload: sharedCached, cache: 'hit', timing };
    }
    const vector = await embedOne(c.env, tenant, normalizedQuery, semanticModel, timing);
    const payload = await queryByVector(c, vector, body, timing);
    if (payload.data.length > 0) {
      queryCache.set(cacheKey, payload);
      await persistSharedQueryCache(c, tenant, indexId, cacheKey, payload);
    }
    timing.cache = 'miss';
    timing.total_ms = elapsedMs(started);
    return { payload, cache: 'miss', timing };
  }

  app.get('/v1/healthz', async (c) => {
    try {
      await c.env.DB.prepare('SELECT 1 AS ok').first();
      return c.json({ ok: true, d1: true, vectorize: Boolean(c.env.VECTORIZE), version: '0.1.0' });
    } catch (error) {
      return c.json({ ok: false, d1: false, vectorize: Boolean(c.env.VECTORIZE), error: String(error) }, 503);
    }
  });

  app.use('/v1/*', requireServiceKey);

  app.post('/v1/indexes', async (c) => {
    const tenant = c.get('tenant');
    const body = (await c.req.json().catch(() => ({}))) as CreateIndexBody;
    const name = body.name?.trim();
    if (!name) return c.json({ error: 'name is required' }, 400);
    const repo = makeRepository(c.env);
    const index = await repo.createIndex({
      id: crypto.randomUUID(),
      tenant,
      name,
      externalId: body.external_id ?? null,
    });
    rememberIndex(c.env, tenant, index.id);
    return c.json(index, 201);
  });

  app.get('/v1/indexes', async (c) => {
    const repo = makeRepository(c.env);
    return c.json({ data: await repo.listIndexes(c.get('tenant')) });
  });

  app.delete('/v1/indexes/:id', async (c) => {
    const tenant = c.get('tenant');
    const indexId = c.req.param('id');
    const repo = makeRepository(c.env);
    const index = await repo.getIndex(tenant, indexId);
    if (!index) return c.json({ error: 'Not found' }, 404);
    const chunkIds = await repo.getChunkIdsForIndex(tenant, indexId);
    await deleteVectors(c.env, chunkIds);
    if (c.env.VECTORIZE_SMALL) await deleteVectors(c.env, chunkIds, 'small');
    await repo.deleteIndex(tenant, indexId);
    queryCache.clear();
    indexCache.clear();
    clearLexicalChunkCache(tenant, indexId);
    await clearSharedQueryCache(c.env, tenant, indexId);
    return c.json({ ok: true });
  });

  app.post('/v1/indexes/:id/ingest', async (c) => {
    const tenant = c.get('tenant');
    const indexId = c.req.param('id');
    const body = (await c.req.json().catch(() => ({}))) as IngestBody;
    const documents = body.documents ?? [];
    if (!Array.isArray(documents) || documents.length === 0) {
      return c.json({ error: 'documents array is required' }, 400);
    }
    const repo = makeRepository(c.env);
    const index = await repo.getIndex(tenant, indexId);
    if (!index) return c.json({ error: 'Index not found' }, 404);

    const out: Array<{ document_id: string; chunks_created: number }> = [];
    for (const input of documents) {
      const content = input.content?.trim();
      if (!content) return c.json({ error: 'document content is required' }, 400);
      if (content.length > MAX_DOC_SIZE) return c.json({ error: 'document content too large' }, 413);

      const document = await repo.createDocument({
        id: crypto.randomUUID(),
        tenant,
        indexId,
        externalId: input.external_id ?? null,
        content,
        metadata: jsonRecord(input.metadata),
      });
      const chunkContents = chunkText(content, body.chunking);
      const vectors = await embed(c.env, chunkContents, { model: embeddingModel(c.env, 'base') });
      const smallVectors = c.env.VECTORIZE_SMALL
        ? await embed(c.env, chunkContents, { model: embeddingModel(c.env, 'small') })
        : [];
      const chunkRows: CreateChunkInput[] = chunkContents.map((chunk, i) => ({
        id: crypto.randomUUID(),
        tenant,
        indexId,
        documentId: document.id,
        content: chunk,
        chunkIndex: i,
        metadata: jsonRecord(input.metadata),
      }));
      await repo.insertChunks(chunkRows);
      const vectorRows: VectorizeVector[] = chunkRows.map((chunk, i) => ({
        id: chunk.id,
        values: vectors[i] ?? [],
        namespace: vectorNamespace(tenant, indexId),
        metadata: vectorMetadata(
          tenant,
          indexId,
          document.id,
          chunk.chunkIndex,
          chunk.content,
          chunk.metadata,
        ),
      }));
      if (vectorRows.length > 0) await c.env.VECTORIZE.upsert(vectorRows);
      if (c.env.VECTORIZE_SMALL && smallVectors.length > 0) {
        const smallRows: VectorizeVector[] = chunkRows.map((chunk, i) => ({
          id: chunk.id,
          values: smallVectors[i] ?? [],
          namespace: vectorNamespace(tenant, indexId),
          metadata: vectorMetadata(
            tenant,
            indexId,
            document.id,
            chunk.chunkIndex,
            chunk.content,
            chunk.metadata,
          ),
        }));
        await c.env.VECTORIZE_SMALL.upsert(smallRows);
      }
      queryCache.clear();
      clearLexicalChunkCache(tenant, indexId);
      await clearSharedQueryCache(c.env, tenant, indexId);
      out.push({ document_id: document.id, chunks_created: chunkRows.length });
    }
    return c.json({ documents: out }, 201);
  });

  app.get('/v1/indexes/:id/documents', async (c) => {
    const tenant = c.get('tenant');
    const indexId = c.req.param('id');
    const repo = makeRepository(c.env);
    const index = await repo.getIndex(tenant, indexId);
    if (!index) return c.json({ error: 'Index not found' }, 404);
    const page = Math.max(Number(c.req.query('page') ?? 1), 1);
    const limit = Math.min(Math.max(Number(c.req.query('limit') ?? 50), 1), 100);
    const data = await repo.listDocuments(tenant, indexId, limit, (page - 1) * limit);
    return c.json({ data, page, limit });
  });

  app.post('/v1/indexes/:id/ingest-vectors', async (c) => {
    const tenant = c.get('tenant');
    const indexId = c.req.param('id');
    const body = (await c.req.json().catch(() => ({}))) as IngestVectorsBody;
    const chunks = body.chunks ?? [];
    if (!Array.isArray(chunks) || chunks.length === 0) {
      return c.json({ error: 'chunks array is required' }, 400);
    }
    const repo = makeRepository(c.env);
    const index = await repo.getIndex(tenant, indexId);
    if (!index) return c.json({ error: 'Index not found' }, 404);

    const docsToCreate = new Map<string, { content: string; externalId: string | null }>();
    const chunkRows: CreateChunkInput[] = [];
    const vectorRows: VectorizeVector[] = [];
    for (const input of chunks) {
      if (!input.id?.trim()) return c.json({ error: 'chunk id is required' }, 400);
      if (!input.document_id?.trim()) return c.json({ error: 'document_id is required' }, 400);
      if (!input.content?.trim()) return c.json({ error: 'chunk content is required' }, 400);
      if (!Array.isArray(input.embedding) || input.embedding.length === 0) {
        return c.json({ error: 'embedding is required' }, 400);
      }
      const chunkId = input.id;
      const documentId = input.document_id;
      const content = input.content;
      const embedding = input.embedding;
      const chunkIndex = Number.isInteger(input.chunk_index) ? (input.chunk_index as number) : chunkRows.length;
      const existingDoc = await repo.getDocument(tenant, documentId);
      if (!existingDoc && !docsToCreate.has(documentId)) {
        docsToCreate.set(documentId, {
          content: input.document_content ?? content,
          externalId: input.document_external_id ?? null,
        });
      }
      const metadata = jsonRecord(input.metadata);
      chunkRows.push({
        id: chunkId,
        tenant,
        indexId,
        documentId,
        content,
        chunkIndex,
        metadata,
      });
      vectorRows.push({
        id: chunkId,
        values: embedding,
        namespace: vectorNamespace(tenant, indexId),
        metadata: vectorMetadata(
          tenant,
          indexId,
          documentId,
          chunkIndex,
          content,
          metadata,
        ),
      });
    }

    for (const [documentId, doc] of docsToCreate) {
      await repo.createDocument({
        id: documentId,
        tenant,
        indexId,
        externalId: doc.externalId,
        content: doc.content,
        metadata: {},
      });
    }
    await repo.insertChunks(chunkRows);
    await c.env.VECTORIZE.upsert(vectorRows);
    queryCache.clear();
    clearLexicalChunkCache(tenant, indexId);
    await clearSharedQueryCache(c.env, tenant, indexId);
    return c.json({ upserted: vectorRows.length }, 201);
  });

  app.delete('/v1/documents/:id', async (c) => {
    const tenant = c.get('tenant');
    const docId = c.req.param('id');
    const repo = makeRepository(c.env);
    const doc = await repo.getDocument(tenant, docId);
    if (!doc) return c.json({ error: 'Not found' }, 404);
    const chunkIds = await repo.getChunkIdsForDocument(tenant, docId);
    await deleteVectors(c.env, chunkIds);
    if (c.env.VECTORIZE_SMALL) await deleteVectors(c.env, chunkIds, 'small');
    await repo.deleteDocument(tenant, docId);
    queryCache.clear();
    indexCache.clear();
    clearLexicalChunkCache(tenant, doc.index_id);
    await clearSharedQueryCache(c.env, tenant, doc.index_id);
    return c.json({ ok: true });
  });

  async function queryByVector(
    c: AppContext,
    vector: number[],
    body: QueryBody,
    timing?: RagTiming,
  ): Promise<QueryPayload> {
    const tenant = c.get('tenant');
    const indexId = c.req.param('id');
    if (!indexId) throw new Error('Index not found');
    const repo = makeRepository(c.env);
    const topK = clampTopK(body.top_k);
    const semanticModel = semanticModelFromBody(body);
    const binding = vectorizeBinding(c.env, semanticModel);
    const filter = userVectorFilter(body.filter);
    const vectorizeStarted = performance.now();
    let query = await binding.query(vector, {
      topK,
      ...(filter ? { filter } : {}),
      namespace: vectorNamespace(tenant, indexId),
      returnMetadata: 'all',
      returnValues: false,
    });
    let vectorizePath = 'namespace';
    if (query.matches.length === 0 && semanticModel === 'base') {
      query = await binding.query(vector, {
        topK,
        filter: { ...jsonRecord(body.filter), tenant, index_id: indexId },
        returnMetadata: 'all',
        returnValues: false,
      });
      vectorizePath = 'metadata_filter_fallback';
    }
    if (timing) timing.vectorize_ms = elapsedMs(vectorizeStarted);
    if (timing) {
      timing.vectorize_path = vectorizePath;
      timing.semantic_model = semanticModel;
    }
    const minScore = typeof body.min_score === 'number' ? body.min_score : -Infinity;
    const matches = query.matches.filter((match) => match.score >= minScore);
    if (matches.length === 0) {
      const indexStarted = performance.now();
      if (!(await indexExists(c.env, repo, tenant, indexId))) throw new Error('Index not found');
      if (timing) timing.index_ms = elapsedMs(indexStarted);
      return { data: [] };
    }
    const metadataResults = matches.map(searchResultFromVectorMetadata);
    if (metadataResults.every(Boolean)) {
      if (timing) timing.hydrate_ms = 0;
      return { data: metadataResults.filter((result): result is SearchResult => Boolean(result)) };
    }
    const hydrateStarted = performance.now();
    const chunkIds = matches.map((match) => match.id);
    const chunks = sortResultsByVectorOrder(chunkIds, await repo.getChunksByIds(tenant, chunkIds));
    const scoreById = new Map(matches.map((match) => [match.id, match.score]));
    const data: SearchResult[] = chunks.map((chunk) => ({
      document_id: chunk.document_id,
      chunk_id: chunk.id,
      chunk_content: chunk.content,
      score: scoreById.get(chunk.id) ?? 0,
      metadata: chunk.metadata,
    }));
    if (timing) timing.hydrate_ms = elapsedMs(hydrateStarted);
    return { data };
  }

  async function queryByLexical(
    c: AppContext,
    query: string,
    body: QueryBody,
    timing?: RagTiming,
  ): Promise<QueryPayload | null> {
    const tokens = tokenizeLexicalQuery(query);
    if (tokens.length === 0) return null;
    const started = performance.now();
    const tenant = c.get('tenant');
    const indexId = c.req.param('id');
    if (!indexId) throw new Error('Index not found');
    const topK = clampTopK(body.top_k);
    const repo = makeRepository(c.env);
    const allChunks = await getCachedLexicalChunks(c.env, repo, tenant, indexId, timing);
    if (allChunks.length === 0) {
      const indexStarted = performance.now();
      if (!(await indexExists(c.env, repo, tenant, indexId))) throw new Error('Index not found');
      if (timing) timing.index_ms = elapsedMs(indexStarted);
    }
    const chunks = allChunks
      .map((chunk) => ({
        ...chunk,
        lexical_score: tokens.filter((token) => chunk.content.toLowerCase().includes(token)).length,
      }))
      .filter((chunk) => chunk.lexical_score > 0)
      .sort((a, b) => b.lexical_score - a.lexical_score || a.chunk_index - b.chunk_index)
      .slice(0, topK);
    if (timing) {
      timing.lexical_ms = elapsedMs(started);
      timing.lexical_tokens = tokens.length;
      timing.retrieval = chunks.length > 0 ? 'lexical' : 'semantic_fallback';
    }
    return {
      data: chunks.map((chunk) => ({
        document_id: chunk.document_id,
        chunk_id: chunk.id,
        chunk_content: chunk.content,
        score: chunk.lexical_score / tokens.length,
        metadata: chunk.metadata,
      })),
    };
  }

  app.post('/v1/indexes/:id/query', async (c) => {
    const started = performance.now();
    const body = (await c.req.json().catch(() => ({}))) as QueryBody;
    const query = body.query?.trim();
    if (!query) return c.json({ error: 'query is required' }, 400);
    try {
      const result = await runTextQuery(c, query, body);
      return c.json(result.payload, 200, withTimingHeaders(result.timing, result.cache, started));
    } catch (error) {
      if (error instanceof Error && error.message === 'Index not found') {
        return c.json({ error: 'Index not found' }, 404);
      }
      throw error;
    }
  });

  app.post('/v1/indexes/:id/benchmark-query', async (c) => {
    const body = (await c.req.json().catch(() => ({}))) as BenchmarkQueryBody;
    const queries = (Array.isArray(body.queries) ? body.queries : [])
      .map((query) => String(query || '').trim())
      .filter(Boolean)
      .slice(0, MAX_BENCHMARK_QUERIES);
    if (queries.length === 0) return c.json({ error: 'queries array is required' }, 400);
    const repeat = Math.min(Math.max(Math.trunc(Number(body.repeat ?? 10)), 1), MAX_BENCHMARK_REPEAT);
    const warmup = Math.min(Math.max(Math.trunc(Number(body.warmup ?? 1)), 0), MAX_BENCHMARK_WARMUP);
    const queryBody: QueryBody = {};
    if (body.top_k !== undefined) queryBody.top_k = body.top_k;
    if (body.filter !== undefined) queryBody.filter = body.filter;
    if (body.min_score !== undefined) queryBody.min_score = body.min_score;
    if (body.mode !== undefined) queryBody.mode = body.mode;
    if (body.semantic_model !== undefined) queryBody.semantic_model = body.semantic_model;
    try {
      for (let pass = 0; pass < warmup; pass += 1) {
        for (const query of queries) {
          await runTextQuery(c, query, queryBody);
        }
      }

      const samples: number[] = [];
      const serverSamples: number[] = [];
      const measured: Array<{
        query: string;
        pass: number;
        ms: number;
        server_ms: number | null;
        cache: 'hit' | 'miss';
        result_count: number;
        top_score: number | null;
      }> = [];
      let cacheHits = 0;
      for (let pass = 0; pass < repeat; pass += 1) {
        for (const query of queries) {
          const started = performance.now();
          const result = await runTextQuery(c, query, queryBody);
          const elapsed = elapsedMs(started);
          const serverMs = typeof result.timing.total_ms === 'number' ? result.timing.total_ms : null;
          samples.push(elapsed);
          if (serverMs !== null) serverSamples.push(serverMs);
          if (result.cache === 'hit') cacheHits += 1;
          measured.push({
            query,
            pass,
            ms: elapsed,
            server_ms: serverMs,
            cache: result.cache,
            result_count: result.payload.data.length,
            top_score: result.payload.data[0]?.score ?? null,
          });
        }
      }
      return c.json({
        index_id: c.req.param('id'),
        queries: queries.length,
        repeat,
        warmup,
        samples: samples.length,
        latency: summarizeLatencies(samples),
        server_latency: summarizeLatencies(serverSamples),
        cache_hits: cacheHits,
        cache_hit_rate: samples.length ? cacheHits / samples.length : 0,
        measurements: measured,
      });
    } catch (error) {
      if (error instanceof Error && error.message === 'Index not found') {
        return c.json({ error: 'Index not found' }, 404);
      }
      throw error;
    }
  });

  app.post('/v1/indexes/:id/query-vector', async (c) => {
    const started = performance.now();
    const timing: RagTiming = { route: 'query-vector' };
    const body = (await c.req.json().catch(() => ({}))) as QueryBody;
    if (!Array.isArray(body.vector) || body.vector.length === 0) {
      return c.json({ error: 'vector is required' }, 400);
    }
    const tenant = c.get('tenant');
    const cacheKey = buildCacheKey({
      tenant,
      indexId: c.req.param('id'),
      vector: body.vector,
      topK: clampTopK(body.top_k),
      filter: jsonRecord(body.filter),
      minScore: typeof body.min_score === 'number' ? body.min_score : null,
      semanticModel: semanticModelFromBody(body),
    });
    queryCache.configure(parseCacheOptions(c.env));
    const cached = queryCache.get(cacheKey);
    if (cached) return c.json(cached, 200, withTimingHeaders(timing, 'hit', started));
    try {
      const payload = await queryByVector(c, body.vector, body, timing);
      if (payload.data.length > 0) queryCache.set(cacheKey, payload);
      return c.json(payload, 200, withTimingHeaders(timing, 'miss', started));
    } catch (error) {
      if (error instanceof Error && error.message === 'Index not found') {
        return c.json({ error: 'Index not found' }, 404);
      }
      throw error;
    }
  });

  return app;
}

export default createApp();
