import { describe, expect, it, vi } from 'vitest';
import { runDeployReadiness } from '../scripts/deploy-readiness.mjs';

describe('deploy-readiness', () => {
  it('passes public checks and marks auth as skipped without a key', async () => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => {
      if (url.endsWith('/v1/healthz')) {
        return Response.json({ ok: true, d1: true, vectorize: true, version: '0.1.0' });
      }
      if (url.endsWith('/v1/indexes')) {
        return Response.json({ error: 'unauthorized' }, { status: 401 });
      }
      return Response.json({ error: 'unexpected' }, { status: 500 });
    }));

    const result = await runDeployReadiness({
      baseUrl: 'http://rag.local',
      key: '',
      exportInput: '',
      requireAuth: false,
    });

    expect(result.ok).toBe(true);
    expect(result.checks).toEqual([
      expect.objectContaining({ name: 'public-health', ok: true }),
      expect.objectContaining({ name: 'protected-indexes-require-auth', ok: true }),
      expect.objectContaining({ name: 'authenticated-key-present', ok: true, skipped: true }),
    ]);
  });

  it('fails when authenticated checks are required without a key', async () => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => {
      if (url.endsWith('/v1/healthz')) {
        return Response.json({ ok: true, d1: true, vectorize: true });
      }
      return Response.json({ error: 'unauthorized' }, { status: 401 });
    }));

    const result = await runDeployReadiness({
      baseUrl: 'http://rag.local',
      key: '',
      exportInput: '',
      requireAuth: true,
    });

    expect(result.ok).toBe(false);
    expect(result.checks.at(-1)).toMatchObject({
      name: 'authenticated-key-present',
      ok: false,
    });
  });

  it('runs authenticated list check when a key is available', async () => {
    const calls: Array<{ url: string; auth: string | null }> = [];
    vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
      calls.push({ url, auth: new Headers(init?.headers).get('authorization') });
      if (url.endsWith('/v1/healthz')) {
        return Response.json({ ok: true, d1: true, vectorize: true });
      }
      if (url.endsWith('/v1/indexes') && !new Headers(init?.headers).has('authorization')) {
        return Response.json({ error: 'unauthorized' }, { status: 401 });
      }
      if (url.endsWith('/v1/indexes')) {
        return Response.json({ data: [] });
      }
      return Response.json({ error: 'unexpected' }, { status: 500 });
    }));

    const result = await runDeployReadiness({
      baseUrl: 'http://rag.local',
      key: 'service-key',
      exportInput: '',
      requireAuth: true,
    });

    expect(result.ok).toBe(true);
    expect(result.checks).toContainEqual(expect.objectContaining({
      name: 'authenticated-index-list',
      ok: true,
      count: 0,
    }));
    expect(calls.at(-1)?.auth).toBe('Bearer service-key');
  });
});
