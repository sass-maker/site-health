#!/usr/bin/env node

import { readFile } from 'node:fs/promises';
import { smokeSaasMakerExport } from './smoke-saas-maker-export.mjs';

const DEFAULT_BASE_URL = 'https://rag-service.sarthakagrawal927.workers.dev';

function usage() {
  console.error(`Usage:
  node scripts/deploy-readiness.mjs [--base-url https://rag-service.<subdomain>.workers.dev]

Options:
  --key <service-key>       Service key for authenticated checks. Defaults to RAG_SERVICE_KEY.
  --export-input <path>     SaaS Maker export JSON to smoke through ingest-vectors.
  --require-auth            Fail if no service key is available.
  --json                    Print JSON only.

Default checks do not require secrets:
  - GET /v1/healthz returns ok, D1, and Vectorize true
  - GET /v1/indexes without a key is rejected with 401`);
}

function parseArgs(argv) {
  const out = {
    baseUrl: process.env.RAG_BASE_URL || DEFAULT_BASE_URL,
    key: process.env.RAG_SERVICE_KEY || '',
    exportInput: '',
    requireAuth: false,
    jsonOnly: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--') continue;
    if (arg === '--require-auth') {
      out.requireAuth = true;
      continue;
    }
    if (arg === '--json') {
      out.jsonOnly = true;
      continue;
    }
    const value = argv[i + 1];
    if (!value) throw new Error(`missing value for ${arg}`);
    i += 1;
    if (arg === '--base-url') out.baseUrl = value;
    else if (arg === '--key') out.key = value;
    else if (arg === '--export-input') out.exportInput = value;
    else throw new Error(`unknown argument: ${arg}`);
  }

  out.baseUrl = out.baseUrl.replace(/\/+$/, '');
  return out;
}

async function requestJson(url, { key, method = 'GET' } = {}) {
  const headers = key ? { Authorization: `Bearer ${key}` } : {};
  const res = await fetch(url, { method, headers });
  const payload = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, payload };
}

function check(name, ok, detail = {}) {
  return { name, ok, ...detail };
}

export async function runDeployReadiness(options) {
  const checks = [];

  const health = await requestJson(`${options.baseUrl}/v1/healthz`);
  checks.push(check('public-health', health.ok && health.payload?.ok === true && health.payload?.d1 === true && health.payload?.vectorize === true, {
    status: health.status,
    payload: health.payload,
  }));

  const protectedProbe = await requestJson(`${options.baseUrl}/v1/indexes`);
  checks.push(check('protected-indexes-require-auth', protectedProbe.status === 401, {
    status: protectedProbe.status,
  }));

  if (!options.key) {
    checks.push(check('authenticated-key-present', !options.requireAuth, {
      skipped: true,
      reason: 'RAG_SERVICE_KEY or --key is required for authenticated checks',
    }));
  } else {
    const indexes = await requestJson(`${options.baseUrl}/v1/indexes`, { key: options.key });
    checks.push(check('authenticated-index-list', indexes.ok && Array.isArray(indexes.payload?.data), {
      status: indexes.status,
      count: Array.isArray(indexes.payload?.data) ? indexes.payload.data.length : null,
    }));

    if (options.exportInput) {
      const input = await readFile(options.exportInput, 'utf8');
      const smoke = await smokeSaasMakerExport({
        baseUrl: options.baseUrl,
        key: options.key,
        input,
        topK: 5,
        limit: 5,
        settleMs: 5000,
        maxWaitMs: 60000,
        pollMs: 3000,
        keepIndex: false,
        dryRun: false,
      });
      checks.push(check('authenticated-export-smoke', smoke.hit_rate === 1, {
        hit_rate: smoke.hit_rate,
        latency: smoke.latency,
        attempts: smoke.attempts,
        waited_ms: smoke.waited_ms,
      }));
    }
  }

  return {
    ok: checks.every((item) => item.ok),
    base_url: options.baseUrl,
    checks,
  };
}

function printHuman(result) {
  for (const item of result.checks) {
    const status = item.ok ? 'PASS' : 'FAIL';
    const suffix = item.skipped ? ` (${item.reason})` : '';
    console.log(`${status} ${item.name}${suffix}`);
  }
  console.log(`\n${result.ok ? 'READY' : 'NOT READY'} ${result.base_url}`);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const args = parseArgs(process.argv.slice(2));
    const result = await runDeployReadiness(args);
    if (args.jsonOnly) console.log(JSON.stringify(result, null, 2));
    else printHuman(result);
    if (!result.ok) process.exitCode = 1;
  } catch (error) {
    usage();
    console.error(`\nError: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}
