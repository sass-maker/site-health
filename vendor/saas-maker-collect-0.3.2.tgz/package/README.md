# @saas-maker/collect

Reusable Node.js package for bounded public web extraction. Site Health owns
brand monitoring, evidence and follow-ups; this package owns only collection.
The CLI commands retain their original entry points. HTTP 401, 403 and 429 now
stop immediately in both the SDK and CLI, without retry or browser escalation.

```js
import { createCollector } from "@saas-maker/collect";

const collector = createCollector({ cacheFile: "/private/local/cache.json" });
try {
  const page = await collector.collect({ url: "https://example.com", extractor: "page" });
  console.log(page.data); // title, description, headings, links, text
} finally {
  await collector.close();
}
```

Importing starts no service and launches no browser. HTTP is the default;
opt into `browserFallback: true` to use installed Chrome for rendered pages.
JSON and text sources use HTTP. `collectMany` accepts at most 100 targets and
returns successful results alongside explicit per-target failures. HTTP 401,
403 and 429 stop with `upstream_blocked` without browser escalation or retry.
Cache is in memory unless the consumer supplies `cacheFile`. Both forms retain
at most 128 entries and 16 MB of serialized entries, evicting least recently
used entries. Larger individual entries are not cached; oversized persisted
files are discarded without loading their contents. Persisted caches
contain collected public content: keep them outside Git and private artifacts.
The consumer chooses and authorizes source URLs; this is an operator library,
not an endpoint for untrusted URL submissions.

`validateUrl` checks the target and jobs careers URL before collection, then
each HTTP request and redirect. A denial returns nonretryable `url_policy_denied`.
Collectors with this policy default to HTTP even when
`browserFallback` is enabled; explicit `auto` and `browser` cannot enforce this policy
and are refused. JSON and text always use HTTP and reject those transports.
`close()` stops admission, rejects queued collections, and waits for active
collections before saving cache and closing Chrome. Active HTTP work that later
needs browser escalation is rejected with `collector_closed`, as is queued work;
an already running browser collection may finish. SDK-generated temporary
browser profiles are deleted on close; caller-supplied profiles are preserved.
Each HTTP retry attempt has one timeout shared by all redirect hops.

`pnpm pack --pack-destination /private/local/packages` produces an installable
tarball with the library, TypeScript declarations, README and MIT attribution.
No profiles, logs, caches, collected data or runtime credentials are packaged.

This is SaaS Maker shared collection tooling, formerly the standalone Slow SERP repo. Source history: sarthakagrawal927 / Significant-Hobbies/slow-serp @ `ae8662f`. It is not a hosted service or a CAPTCHA bypass. Google search remains unavailable in the checked environment: standard automated Chrome reached Google's CAPTCHA on 2026-10-25. An approved SERP connection is needed before claiming working search.

It provides a local scraping API and scheduled crawler. It uses bounded HTTP fetching first, then automatically falls back to the machine's installed **Google Chrome** only when rendering is required.

It has three entry points:

- `pnpm start` exposes the paced Google search API.
- `pnpm run jobs` collects normalized public job listings into dated JSON and CSV.
- `pnpm run crawl` runs the general target registry, capturing ordinary pages or invoking the jobs extractor as configured.

This is intentionally not a CAPTCHA solver or an aggressive crawler. If Google returns a consent, unusual-traffic, or challenge page, the API stops with an `upstream_blocked` error so the profile or egress can be checked by a human.

## Design

- Real installed Chrome, not Playwright's bundled Chromium.
- Fast HTTP-first extraction with bounded response sizes and streaming reads.
- ETag, Last-Modified, and content-hash reuse between scheduled runs.
- Configurable headful/headless persistent context.
- One paced queue per Google-search instance.
- Bounded browser concurrency with one active page per hostname.
- Optional blocking of images, fonts, media, stylesheets, and service workers for lower background resource use.
- Proxy credentials supplied only at runtime.
- API-key authentication when the HTTP service is exposed beyond localhost.
- No automatic CAPTCHA interaction.

## Requirements

- Node.js 22 or newer.
- Google Chrome installed.
- A display only when `SCRAPER_HEADLESS=false`. Headless scheduled crawls do not require one.

## Install and verify

```bash
git clone https://github.com/sass-maker/saas-maker.git
cd saas-maker
cd tooling/collect
pnpm install --frozen-lockfile
pnpm test
pnpm run doctor
```

Run the general registry or the dedicated jobs collector:

```bash
SCRAPER_HEADLESS=true SCRAPER_BLOCK_RESOURCES=true pnpm run crawl
SCRAPER_HEADLESS=true SCRAPER_BLOCK_RESOURCES=true pnpm run jobs
```

## General targets

The general crawler reads `targets/default.json`. A target can capture an ordinary page:

```json
{
  "name": "Example page",
  "url": "https://example.com/",
  "extractor": "page"
}
```

Targets default to `"transport": "auto"`. Set it to `"http"` to forbid browser fallback or `"browser"` when a site always requires JavaScript or a persistent session.

Public APIs and feeds can use `"extractor": "json"` or `"extractor": "text"`; these use HTTP transport exclusively.

Or it can invoke the jobs adapter with URL allow-patterns:

```json
{
  "name": "Example careers",
  "company": "Example",
  "url": "https://example.com/careers",
  "extractor": "jobs",
  "jobUrlIncludes": ["example.com/careers/"]
}
```

Each crawl writes `data/crawls/latest.json` plus a gzip-compressed timestamped run. A failed target is recorded without discarding successful targets. Override the registry or output directory with `SCRAPER_TARGETS_FILE` and `SCRAPER_OUTPUT_DIR`.

## Background operation on macOS

The bundled LaunchAgent runs `pnpm run crawl` immediately and every six hours. It uses headless Chrome, three concurrent target pages, resource blocking, `caffeinate` during each run, and local log files. No credentials are embedded in the agent.

The scheduled crawler uses its own Chrome profile so it cannot collide with an independently running API service.

```bash
pnpm run macos:validate
pnpm run macos:install
pnpm run macos:status
```

Results appear under `data/crawls/`; logs appear under `logs/`. Keep the Mac powered and connected to the network. To stop and remove the background job:

```bash
pnpm run macos:uninstall
```

## Google search API

Run a direct smoke test or start the local service:

```bash
pnpm run smoke -- "best mechanical keyboards"
SCRAPER_API_KEY='replace-with-a-strong-random-value' pnpm start
```

The service binds to `127.0.0.1:8787` by default. Keep that default and put an authenticated TLS reverse proxy in front of it, or deliberately set a private-network bind address.

- `GET /health` reports readiness, queue depth, pacing, and whether a proxy is configured; it never returns proxy credentials.
- `POST /v1/search` accepts `q`, `num` (1–10), `start` (0–90), `hl`, and `gl`.

Example request:

```bash
curl -sS http://127.0.0.1:8787/v1/search \
  -H 'content-type: application/json' \
  -H "authorization: Bearer $SCRAPER_API_KEY" \
  --data '{"q":"playwright persistent context","num":5,"hl":"en","gl":"us"}'
```

## Apple App Store collection

`@saas-maker/collect/apple` is a dependency-free subpath for credential-free
public Apple search/lookup. Importing it starts no service, browser or scheduler,
reads no credentials and writes no cache or files.

```js
import { createAppleCollector, appleSourceUrl } from "@saas-maker/collect/apple";

const apple = createAppleCollector({
  async reserve({ query, sourceUrl, signal }) {
    // The owner supplies its shared persisted provider quota here.
    await providerGate.reserve({ query, sourceUrl, signal });
  },
});
const capture = await apple.search({
  term: "notes", country: "us", platform: "ios", limit: 50,
}, { signal: controller.signal });
```

`reserve` is required and runs before every network dispatch. A rejected
reservation propagates unchanged and makes no provider call. The consumer owns
shared pacing, retries, cache and scheduling; this package has no hidden retry or
per-instance cache that could bypass that authority. A Node/SQLite consumer such as Site Health can reserve at most 18 uncached
calls/minute across its processes. Every consumer must supply its own bounded
shared provider gate.

- `search({term,country,platform,limit?}, {signal?})` returns one frozen capture
  `{id,kind:"search",key,sourceUrl,fetchedAt,apps}`. `key` includes normalized
  term, storefront, platform and coverage. Result limit defaults to 50 and must
  be 20–200. Search order stays exactly as returned. Mac search may include iPad apps
  available on Mac; a capture notice explains this. An unexpected native Mac
  result in an iOS search rejects the whole capture rather than shifting positions.
- `lookup({id,country,platform}, {signal?})` accepts only a numeric Apple ID or
  an HTTPS `apps.apple.com/.../app/.../id...` URL (developer URLs are rejected). It returns the same evidence fields
  plus `match:"matched"|"not-found"|"platform-mismatch"` and an optional notice.
  Apple lookup ignores the entity filter: native Mac apps cannot match iOS,
  while software-kind app metadata can match a Mac lookup with a notice that
  Mac compatibility is unconfirmed. A Mac search or App Store check is needed.
  Numeric developer IDs return not-found rather than related apps. Unknown
  rating metadata stays null; missing optional text is empty and actual zero
  ratings stay zero. The requested source/time stays inspectable in every case.
- `normalizeAppleQuery`, `appleSourceUrl` and `parseAppleAppId` are exported
  pure helpers. `APPLE_PROVIDER_VERSION` is available for consumer cache keys.
  Each capture stores the app list once; consumers cache that public capture
  and keep its original ID/time on cache hits. Cache delivery time belongs in a
  separate field, never in `fetchedAt`.
- Provider requests use only `https://itunes.apple.com/search` or `/lookup`.
  Mac uses `macSoftware`, iOS uses `software`. Redirects are refused, bodies
  are limited to 2 MB, and the combined fetch/body deadline is 10 seconds. Tests
  may inject a shorter deadline, fetch implementation and clock. Abort signals
  cancel collection and reservation waiting without scheduling another call.
- `AppleCollectionError` exposes `code`, safe `status` and nullable
  `retryAfter` seconds. Valid Retry-After headers are preserved on any upstream
  HTTP error, including 503; absent or invalid headers yield null. Apple HTTP
  429 remains 429; other upstream HTTP errors map to 502. Network,
  timeout, invalid query, platform mismatch and malformed/oversized response
  states remain distinct. No failure is returned as a successful empty capture.

This subpath owns provider normalization and evidence only. Research boards,
keyword estimates, listing drafts, private storage, owner authentication,
canonical-project attribution and publication are consumer responsibilities.
The public API position does not guarantee native App Store search parity;
absence means missing from the returned set, not a lower or zero rank.

## Runtime configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `CHROME_EXECUTABLE` | auto-detected | Absolute Google Chrome executable path |
| `SCRAPER_HOST` | `127.0.0.1` | HTTP bind address |
| `SCRAPER_PORT` | `8787` | HTTP port |
| `SCRAPER_API_KEY` | unset | Bearer token; required when exposed |
| `SCRAPER_PROFILE_DIR` | `work/chrome-profile` | Persistent Chrome profile directory |
| `SCRAPER_HEADLESS` | `false` | Run Chrome without visible windows |
| `SCRAPER_BLOCK_RESOURCES` | `false` | Skip nonessential browser resources |
| `SCRAPER_BROWSER_CONCURRENCY` | `3` | Concurrent browser fallbacks, capped at 8 |
| `SCRAPER_HTTP_CONCURRENCY` | `12` | Concurrent HTTP targets, capped at 64 |
| `SCRAPER_HTTP_TIMEOUT_MS` | `15000` | HTTP-first timeout before fallback |
| `SCRAPER_HTTP_RETRIES` | `2` | Transient HTTP/network retries |
| `SCRAPER_HTTP_RETRY_BASE_MS` | `500` | Exponential backoff base delay |
| `SCRAPER_MAX_RESPONSE_BYTES` | `5000000` | Maximum buffered HTML response size |
| `SCRAPER_HTTP_CACHE_FILE` | `work/http-cache.json` | Conditional-request/content cache; same 128-entry/16 MB LRU cap as the SDK. Oversized files are discarded on load. |
| `SCRAPER_USER_AGENT` | `slow-serp/0.2 (...)` | HTTP transport user agent |
| `SCRAPER_TARGETS_FILE` | `targets/default.json` | General crawler registry |
| `SCRAPER_OUTPUT_DIR` | `data/crawls` | General crawler output directory |
| `SCRAPER_PROXY_SERVER` | unset | Proxy endpoint, such as `http://host:port` |
| `SCRAPER_PROXY_USERNAME` | unset | Proxy username |
| `SCRAPER_PROXY_PASSWORD` | unset | Proxy password |
| `SCRAPER_MIN_DELAY_MS` | `30000` | Minimum delay between Google searches |
| `SCRAPER_JITTER_MS` | `5000` | Additional randomized Google-search delay |
| `SCRAPER_NAVIGATION_TIMEOUT_MS` | `45000` | Navigation timeout |
| `SCRAPER_MAX_QUEUE_SIZE` | `100` | Maximum queued Google searches |
| `SCRAPER_LOCALE` | `en-US` | Chrome locale |
| `SCRAPER_TIMEZONE` | `UTC` | Chrome timezone |

On a Linux host, set `SCRAPER_HEADLESS=true`. If visible Chrome is required, run under `xvfb-run` while keeping headless mode disabled.

Keep secret values in the machine's process manager or secret store. They are never needed in a checked-in file.
