# rag-service

Standalone Cloudflare RAG service for fleet projects.

This service owns vector ingestion and retrieval behind a service-key API: Cloudflare Worker + Hono, Workers AI embeddings, Vectorize search, D1 for chunk text and metadata, and optional R2 for raw document blobs.

## Local Checks

```bash
pnpm install
pnpm check
pnpm run backfill:dry-run
pnpm run benchmark:dry-run
pnpm run readiness
pnpm run smoke:export:dry-run
```

## Cloudflare Resources

Create these before a real deploy:

```bash
wrangler vectorize create rag-bge-768 --dimensions=768 --metric=cosine
wrangler vectorize create-metadata-index rag-bge-768 --property-name=tenant --type=string
wrangler vectorize create-metadata-index rag-bge-768 --property-name=index_id --type=string
wrangler d1 create rag-db
wrangler d1 migrations apply rag-db
wrangler r2 bucket create rag-raw-docs
wrangler secret put RAG_SERVICE_KEYS
```

`RAG_SERVICE_KEYS` is a JSON object mapping service keys to tenant names:

```json
{
  "replace-with-random-key": "saas-maker"
}
```

Do not commit real keys.

Fleet-level verification lives in SaaS Maker:

```bash
cd ../saas-maker
pnpm fleet:secret-audit -- --project rag-service --fail-on-missing
```

After the secret is set, run the standalone deployed-readiness smoke:

```bash
RAG_SERVICE_KEY=<service-key> pnpm run readiness:auth
```

Without a service key, `pnpm run readiness` still verifies that the deployed
health endpoint is live and protected `/v1/*` routes reject anonymous access.

## API

All `/v1/*` routes require `Authorization: Bearer <service-key>` or `X-RAG-Key: <service-key>`.

- `GET /v1/healthz`
- `POST /v1/indexes`
- `GET /v1/indexes`
- `DELETE /v1/indexes/:id`
- `POST /v1/indexes/:id/ingest`
- `POST /v1/indexes/:id/ingest-vectors`
- `GET /v1/indexes/:id/documents`
- `DELETE /v1/documents/:id`
- `POST /v1/indexes/:id/query`
- `POST /v1/indexes/:id/query-vector`

The first implemented path chunks raw document text, embeds with `@cf/baai/bge-base-en-v1.5`, upserts vectors to Vectorize, stores hydrated chunk text in D1, and queries Vectorize with server-enforced `tenant + index_id` metadata filters.

## Backfill Existing SaaS Maker Chunks

The import script accepts a JSON export of existing saas-maker chunks with precomputed embeddings. It calls `POST /v1/indexes/:id/ingest-vectors`, so no Workers AI re-embedding is needed during migration.

```bash
RAG_BASE_URL=https://rag-service.<your-subdomain>.workers.dev \
RAG_SERVICE_KEY=<service-key> \
node scripts/backfill-saas-maker.mjs \
  --input saas-maker-chunks.json \
  --index-name "SaaS Maker Knowledge" \
  --external-id <saas-maker-index-id>
```

Dry-run a fixture locally:

```bash
pnpm run backfill:dry-run
```

## Smoke A SaaS Maker Export

After exporting an index from SaaS Maker with
`GET /v1/knowledge/indexes/:id/export`, smoke the exact pre-embedded migration
path through RAG service:

```bash
RAG_BASE_URL=https://rag-service.<your-subdomain>.workers.dev \
RAG_SERVICE_KEY=<service-key> \
node scripts/smoke-saas-maker-export.mjs \
  --input saas-maker-knowledge-export.json \
  --limit 10
```

The smoke creates a temporary RAG index, imports the exported vectors, waits and
polls until Vectorize makes them queryable, queries by vector, reports latency and
hit rate, and deletes the temporary index unless `--keep-index` is passed.

The same exported-vector smoke can be run through the readiness wrapper:

```bash
RAG_SERVICE_KEY=<service-key> \
node scripts/deploy-readiness.mjs \
  --require-auth \
  --export-input saas-maker-knowledge-export.json
```

## Benchmark Latency And Hit Rate

The benchmark harness can hit local `wrangler dev` or a deployed Worker. It can create
a temporary index from raw documents, run repeated text queries, and report latency
percentiles, cache hits, and simple expected-result hit rate.

```bash
RAG_BASE_URL=https://rag-service.<your-subdomain>.workers.dev \
RAG_SERVICE_KEY=<service-key> \
node scripts/benchmark-rag.mjs \
  --input fixtures/benchmark.sample.json \
  --repeat 5 \
  --top-k 5
```

Use `--index-id <id>` to benchmark an existing populated index. Add `--cleanup` only
when the script created the benchmark index and you want it deleted after the run.
Fresh-index runs wait 15 seconds after ingest by default so Vectorize can make
newly-upserted vectors queryable before accuracy is scored.
